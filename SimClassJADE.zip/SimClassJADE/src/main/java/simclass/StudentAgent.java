  
package simclass;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.Random;

public class StudentAgent extends Agent {
    private ClassroomUI ui;
    private String studentType;
    private Random random = new Random();
    
    protected void setup() {
        System.out.println("Agent Étudiant démarré: " + getAID().getName());
        
        Object[] args = getArguments();
        if (args != null && args.length > 1) {
            ui = (ClassroomUI) args[0];
            studentType = (String) args[1];
        }
        
        addBehaviour(new StudentBehaviour());
    }
    
    private class StudentBehaviour extends CyclicBehaviour {
        public void action() {
            MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
            ACLMessage msg = myAgent.receive(mt);
            
            if (msg != null) {
                String content = msg.getContent();
                if (content.startsWith("teach:")) {
                    String material = content.substring(6);
                    respondToTeaching(material);
                }
            } else {
                block();
            }
        }
        
        private void respondToTeaching(String material) {
            String response = "";
            
            switch (studentType) {
                case "Bavard":
                    response = "J'ai une question sur " + material;
                    break;
                case "Pensif":
                    response = "Je réfléchis à " + material;
                    break;
                case "PriseDeNotes":
                    response = "Je prends des notes sur: " + material;
                    break;
                case "Curieux":
                    response = "Pourquoi " + material + " est important?";
                    break;
            }
            
            ui.addMessage("Étudiant (" + studentType + ")", response);
        }
    }
}