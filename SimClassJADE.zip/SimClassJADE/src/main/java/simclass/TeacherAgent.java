  
package simclass;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class TeacherAgent extends Agent {
    private ClassroomUI ui;
    private int currentMaterialIndex = 0;
    
    protected void setup() {
        System.out.println("Agent Enseignant démarré: " + getAID().getName());
        
        // Récupérer l'interface utilisateur
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            ui = (ClassroomUI) args[0];
        }
        
        addBehaviour(new TeachBehaviour());
    }
    
    private class TeachBehaviour extends CyclicBehaviour {
        public void action() {
            // Attendre un message pour enseigner
            MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
            ACLMessage msg = myAgent.receive(mt);
            
            if (msg != null) {
                if (currentMaterialIndex < ui.teachingMaterials.size()) {
                    String material = ui.teachingMaterials.get(currentMaterialIndex);
                    ui.addMessage("Enseignant", material);
                    currentMaterialIndex++;
                    
                    // Répondre que l'enseignement est terminé
                    ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
                    reply.addReceiver(msg.getSender());
                    reply.setContent("Material taught: " + material);
                    send(reply);
                }
            } else {
                block();
            }
        }
    }
}