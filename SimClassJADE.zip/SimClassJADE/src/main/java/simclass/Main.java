package simclass;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Démarrer l'interface utilisateur
        ClassroomUI classroomUI = new ClassroomUI();
        
        // Initialiser JADE
        Runtime rt = Runtime.instance();
        Profile p = new ProfileImpl();
        p.setParameter(Profile.MAIN_HOST, "localhost");
        p.setParameter(Profile.MAIN_PORT, "1099");
        p.setParameter(Profile.GUI, "true");
        
        AgentContainer mainContainer = rt.createMainContainer(p);
        
        try {
            // Créer le Manager Agent
            Object[] managerArgs = new Object[]{classroomUI};
            AgentController managerAgent = mainContainer.createNewAgent(
                "manager", "simclass.ManagerAgent", managerArgs);
            
            // Créer l'Assistant Agent
            Object[] assistantArgs = new Object[]{classroomUI};
            AgentController assistantAgent = mainContainer.createNewAgent(
                "assistant", "simclass.AssistantAgent", assistantArgs);
            
            // Créer le Teacher Agent
            Object[] teacherArgs = new Object[]{classroomUI};
            AgentController teacherAgent = mainContainer.createNewAgent(
                "teacher", "simclass.TeacherAgent", teacherArgs);
            
            // Types d'étudiants
            String[] studentTypes = {"Bavard", "Pensif", "PriseDeNotes", "Curieux"};
            for (int i = 0; i < studentTypes.length; i++) {
                Object[] studentArgs = new Object[]{classroomUI, studentTypes[i]};
                AgentController studentAgent = mainContainer.createNewAgent(
                    "student" + i, "simclass.StudentAgent", studentArgs);
                studentAgent.start();
            }
            
            // Démarrer les agents
            managerAgent.start();
            assistantAgent.start();
            teacherAgent.start();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}