  
package simclass;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.Random;

public class AssistantAgent extends Agent {
    private ClassroomUI ui;
    private Random random = new Random();
    
    protected void setup() {
        System.out.println("Agent Assistant démarré: " + getAID().getName());
        
        // Récupérer l'interface utilisateur
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            ui = (ClassroomUI) args[0];
        }
        
        addBehaviour(new AssistBehaviour());
        
        // Message d'introduction
        ui.addMessage("Assistant", "Bonjour! Je suis l'assistant, prêt à aider.");
    }
    
    private class AssistBehaviour extends CyclicBehaviour {
        public void action() {
            // Écouter les demandes d'aide
            MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
            ACLMessage msg = myAgent.receive(mt);
            
            if (msg != null) {
                String content = msg.getContent();
                String sender = msg.getSender().getLocalName();
                
                ui.addMessage("Assistant", "Demande d'aide reçue de " + sender);
                
                // Répondre à la demande d'aide
                if (content.equals("help")) {
                    String[] helpResponses = {
                        "Je peux vous aider avec cela. Voici quelques informations supplémentaires...",
                        "C'est une excellente question! La réponse est...",
                        "Je comprends votre confusion. Permettez-moi d'expliquer...",
                        "Bon point! Voici quelques détails supplémentaires...",
                        "Je suis heureux de pouvoir aider. La solution est..."
                    };
                    
                    String response = helpResponses[random.nextInt(helpResponses.length)];
                    ui.addMessage("Assistant", response);
                    
                    // Répondre à l'expéditeur
                    ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
                    reply.addReceiver(msg.getSender());
                    reply.setContent("help provided");
                    send(reply);
                }
            } else {
                block();
            }
        }
    }
}