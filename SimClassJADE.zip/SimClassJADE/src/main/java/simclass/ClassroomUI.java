  package simclass;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ClassroomUI extends JFrame {
    public JTextArea chatArea;
    private JTextField inputField;
    public List<String> teachingMaterials;
    
    public ClassroomUI() {
        setTitle("SimClass - Classroom Simulation");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Matériaux d'enseignement
        teachingMaterials = new ArrayList<>();
        teachingMaterials.add("Introduction à l'Intelligence Artificielle");
        teachingMaterials.add("Les modèles de langage large (LLM)");
        teachingMaterials.add("Comment les LLM fonctionnent");
        teachingMaterials.add("Applications éducatives des LLM");
        
        // Configuration de l'interface
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        JButton sendButton = new JButton("Envoyer");
        
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);
        
        sendButton.addActionListener(e -> {
            String message = inputField.getText();
            if (!message.trim().isEmpty()) {
                addMessage("Utilisateur", message);
                inputField.setText("");
            }
        });
        
        setVisible(true);
    }
    
    public void addMessage(String sender, String message) {
        chatArea.append(sender + ": " + message + "\n");
    }
}