  
package simclass;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;
import java.util.Random;

public class ManagerAgent extends Agent {
    private ClassroomUI ui;
    private int currentMaterialIndex = 0;
    private Random random = new Random();
    private boolean classActive = true;
    
    protected void setup() {
        System.out.println("Agent Manager démarré: " + getAID().getName());
        
        // Récupérer l'interface utilisateur
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            ui = (ClassroomUI) args[0];
        }
        
        // Ajouter un comportement pour gérer la classe
        addBehaviour(new ClassManagementBehaviour());
        
        // Démarrer la simulation de classe
        addBehaviour(new TickerBehaviour(this, 5000) {
            protected void onTick() {
                if (classActive && currentMaterialIndex < ui.teachingMaterials.size()) {
                    // Enseigner le matériel actuel
                    teachCurrentMaterial();
                } else if (currentMaterialIndex >= ui.teachingMaterials.size()) {
                    // Classe terminée
                    ui.addMessage("Manager", "La classe est terminée. Merci à tous!");
                    classActive = false;
                    stop();
                }
            }
        });
    }
    
    private void teachCurrentMaterial() {
        String material = ui.teachingMaterials.get(currentMaterialIndex);
        ui.addMessage("Manager", "Enseignement du matériel: " + material);
        
        // Simuler l'enseignement en ajoutant un délai
        ui.addMessage("Enseignant", material);
        
        // Après l'enseignement, demander à un étudiant de réagir
        int studentId = random.nextInt(4); // 4 étudiants
        ui.addMessage("Manager", "Demande à l'étudiant " + studentId + " de réagir");
        
        // Simuler la réponse de l'étudiant
        String[] studentTypes = {"Bavard", "Pensif", "PriseDeNotes", "Curieux"};
        String studentType = studentTypes[studentId];
        
        String response = "";
        switch (studentType) {
            case "Bavard":
                response = "J'ai une question sur " + material;
                break;
            case "Pensif":
                response = "Je réfléchis à " + material;
                break;
            case "PriseDeNotes":
                response = "Je prends des notes sur: " + material;
                break;
            case "Curieux":
                response = "Pourquoi " + material + " est important?";
                break;
        }
        
        ui.addMessage("Étudiant " + studentId + " (" + studentType + ")", response);
        
        // Passer au matériel suivant
        currentMaterialIndex++;
    }
    
    private class ClassManagementBehaviour extends CyclicBehaviour {
        public void action() {
            // Écouter les messages des autres agents
            MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.INFORM);
            ACLMessage msg = myAgent.receive(mt);
            
            if (msg != null) {
                String content = msg.getContent();
                String sender = msg.getSender().getLocalName();
                
                ui.addMessage("Manager", "Message reçu de " + sender + ": " + content);
                
                // Gérer différents types de messages
                if (content.contains("help")) {
                    ui.addMessage("Manager", "Demande d'aide détectée, notification de l'assistant");
                    // Notifier l'assistant
                    ACLMessage helpMsg = new ACLMessage(ACLMessage.REQUEST);
                    helpMsg.addReceiver(getAID("assistant"));
                    helpMsg.setContent("help");
                    send(helpMsg);
                }
            } else {
                block();
            }
        }
    }
}